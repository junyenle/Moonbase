package Agents;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import Maps.Map;

public class PlayerOne extends Agent
{

	// animations
	private static final int numAnimations = 3;
	private static final int STAND = 0;
	private static final int RIGHT = 1;
	private static final int LEFT = 2;
	private static final int STANDFRAMES = 1;
	private static final int RIGHTFRAMES = 1;
	private static final int LEFTFRAMES = 1;
	private ArrayList<ArrayList<BufferedImage> > animationFrames = new ArrayList<ArrayList<BufferedImage> >();
	private int animationInterval = 20000000;
	private int animationSelector;
	private int frameSelector;
	// inherited: private long jumpStart;
	
	
	
	public PlayerOne(Map map)
	{
		this.map = map;
		this.agentWidth = 60;
		this.agentHeight = 118;
		int spriteWidth = 120;
		int spriteHeight = 120;
		this.mvtSpd = 20;
		this.mvtDec = 0.5;
		this.fallSpd = 10;
		this.fallTer = 50.0;
		this.jumpPower = -25;
		this.direction = STAND;
		this.jumping = false;
		this.jumped = false;
		this.agentDX = 0;
		this.agentDY = 0;
		
		// set up animatinos
		readAnimations();
	}
	
	public void readAnimations() // 0 = stand, 1 = right, 2 = left
	{
		try 
		{
			BufferedImage spriteSheet = ImageIO.read(getClass().getResourceAsStream("/sprites/playersprites.gif"));
			for(int animation = 0; animation < numAnimations; animation++)
			{
				ArrayList<BufferedImage> temp = new ArrayList<BufferedImage>();
				for(int frame = 0; frame < STANDFRAMES; frame++)
				{
					temp.add(spriteSheet.getSubimage(frame * 120, 0, 120, 120));
				}
				animationFrames.add(temp);

				temp = new ArrayList<BufferedImage>();
				for(int frame = 0; frame < RIGHTFRAMES; frame++)
				{
					temp.add(spriteSheet.getSubimage(frame * 120, 120, 120, 120));
				}
				animationFrames.add(temp);

				temp = new ArrayList<BufferedImage>();
				for(int frame = 0; frame < LEFTFRAMES; frame++)
				{
					temp.add(spriteSheet.getSubimage(frame * 120, 240, 120, 120));
				}
				animationFrames.add(temp);
			}
			
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void update()
	{
		// x direction movement
		if(this.direction == LEFT)
		{
			this.agentDX = - this.mvtSpd;
		}
		else if(this.direction == RIGHT)
		{
			this.agentDX = this.mvtSpd;
		}
		else if(this.direction == STAND)
		{
			this.agentDX = 0;
		}
		
		// y direction movement		
		this.agentDY += this.fallSpd; // gravity never stops
		if(this.agentDY > this.fallTer)
		{
			this.agentDY = this.fallTer;
		}
		if(this.jumping && ((System.nanoTime() - jumpStart < 300000000) || this.jumpStart == -1) && this.jumped == false )
		{
			if(this.jumpStart == -1)
			{
				jumpStart = System.nanoTime();
			}
			System.out.println("jumping");
			this.agentDY = this.jumpPower;
		}
		
		// check for collisions and adjust accordingly
		checkCollisions();
		
		// update current position
		this.agentX = this.xGoal;
		this.agentY = this.yGoal;
		System.out.println(this.agentX + ", " + this.agentX);
		
		// animations
		if(this.agentDX > 0) // moving right
		{
			this.animationSelector = 1;
		}
		else if(this.agentDX < 0)
		{
			this.animationSelector = 2;
		}
		else if(this.agentDX == 0)
		{
			this.animationSelector = 0;
		}
	}
	
	public void draw(Graphics2D graphics)
	{
		this.mapX = map.getX();
		this.mapY = map.getY();
		
		graphics.drawImage(animationFrames.get(animationSelector).get(0), (int) (this.agentX + this.mapX - this.agentWidth / 2), (int) (this.agentY + this.mapY - this.agentHeight / 2), null);

	}
	


	
}
