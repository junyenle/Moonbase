package States;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

import Agents.Agent;
import Agents.PlayerOne;
import Driver.GameWindow;
import Graphics.Background;
import Maps.Map;


public class Tutorial extends GameState
{
	private PlayerOne player;
	private Background bg;
	private Map map;
	protected StateManager manager;
	
	public Tutorial(StateManager manager)
	{
		this.manager = manager;
		setup(); // level setup
	}
	
	public void setup()
	{
		this.bg = new Background("/backgrounds/tutorialbg.gif", 1);
		map = new Map("/tiles/tutorialtiles.gif", "/maps/tutorialmap.txt");
		this.player = new PlayerOne(map);
		player.setPosition(900, 500);
	}
	
	public void update()
	{
		player.update(); // update player data
		map.setPosition(GameWindow.WIDTH / 2 - player.getAgentX(), GameWindow.HEIGHT / 2 - player.getAgentY()); // set the camera position
	}
	
	public void draw(Graphics2D graphics)
	{
		this.bg.draw(graphics); // draw background first
		this.map.draw(graphics); // then the map tiles
		this.player.draw(graphics); // then the player
	}
	
	public void keyPressed(int keyCode)
	{
		if(keyCode == KeyEvent.VK_ESCAPE)
		{
			System.exit(0);
		}
		if(keyCode == KeyEvent.VK_LEFT)
		{
			player.setAgentDX(0);
			player.setDirection(2); // left
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			player.setAgentDX(0);
			player.setDirection(1); // right
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			player.setJumping(true); // + DY
		}
	}
	
	public void keyReleased(int keyCode)
	{
		
		if(keyCode == KeyEvent.VK_LEFT)
		{
			player.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			player.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			player.setJumping(false); // no more + DY
			player.setJumped(true); // can't jump again
		}
	}
	
	
	
	
}
