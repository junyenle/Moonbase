package Agents;

import java.awt.Rectangle;

import Maps.Map;

public abstract class Agent 
{

	// map and pos of map
	protected Map map;
	protected int boxDim = 120;
	protected double mapX;
	protected double mapY;
	
	// agent pos
	protected double agentX;
	protected double agentY;
	protected double agentDX;
	protected double agentDY;
	protected double xGoal;
	protected double yGoal;
	
	protected long jumpStart;
	protected int numJumps;
	protected Boolean jumped;
	
	// coll
	protected int agentHeight;
	protected int agentWidth;
	protected Boolean topLeftBlocked;
	protected Boolean topRightBlocked;
	protected Boolean bottomLeftBlocked;
	protected Boolean bottomRightBlocked;
	protected Boolean topBlocked;
	protected Boolean bottomBlocked;
	protected Boolean rightBlocked;
	protected Boolean leftBlocked;
	
	
	// movement
	protected int thisAction; // what are we doing now?
	protected int lastAction;
	protected Boolean jumping;
	protected Boolean falling;
	protected static final int STAND = 0;
	protected static final int LEFT = 2;
	protected static final int RIGHT = 1;
	protected int direction; // use LEFT and RIGHT
	protected double mvtSpd;
	protected double mvtTer;
	protected double mvtDec;
	protected double fallSpd;
	protected double fallTer;
	protected double jumpPower;
	
	
	public void checkCollisions()
	{
		// check which boxes need to be open to accomplish the desired move
		this.xGoal = this.agentX + this.agentDX;
		this.yGoal = this.agentY + this.agentDY;
		
		// x-wise collision - use xGoal, agentY
		if(this.agentDX > 0 )// to the right
		{
			//top corner blocked
			if(map.getType((int)this.agentY / 120, (int) (xGoal + agentWidth / 2) / 120) == 1)
			{
				xGoal = this.agentX; // don't add DX
				this.agentDX = 0;
			}
			// bottom corner blocked
			if(map.getType((int)(this.agentY + this.agentHeight / 2) / 120, (int) (xGoal + agentWidth / 2) / 120) == 1)
			{
				xGoal = this.agentX; // don't add DX
				this.agentDX = 0;
			}		
		}
		else if(this.agentDX < 0 )// to the left
		{
			//top corner blocked
			if(map.getType((int)this.agentY / 120, (int) (xGoal - agentWidth / 2) / 120) == 1)
			{
				xGoal = this.agentX; // don't add DX
				this.agentDX = 0;
			}
			// bottom corner blocked
			if(map.getType((int)(this.agentY + this.agentHeight / 2) / 120, (int) (xGoal - agentWidth / 2) / 120) == 1)
			{
				xGoal = this.agentX; // don't add DX
				this.agentDX = 0;
			}		
		}
		
		// y-wise collision - use agentX, yGoal
		if(this.agentDY > 0) //downwards
		{
			Boolean isInAir = true;
			// left corner blocked
			//System.out.println(yGoal + " : " + this.agentHeight + " : " + this.agentX);
			if(map.getType((int)(yGoal + this.agentHeight / 2) / 120, (int)(this.agentX - agentWidth / 2) / 120) == 1)
			{
				yGoal = this.agentY; // don't add DY
				this.agentDY = 0;
				this.jumpStart = -1;
				this.jumped = false;
				isInAir = false;
			}
			// right corner blocked
			if(map.getType((int)(yGoal + this.agentHeight / 2) / 120, (int)(this.agentX + this.agentWidth / 2) / 120) == 1)
			{
				yGoal = this.agentY; // don't add DY
				this.agentDY = 0;
				this.jumpStart = -1;
				this.jumped = false;
				isInAir = false;
			}
			
			if(isInAir) // in air, counts as a jump
			{
				this.jumped = true;
			}
		}
		
		if(this.agentDY < 0) // upwards
		{
			// same as down basically
			// left corner blocked
			if(map.getType((int)(yGoal - this.agentHeight / 2) / 120, (int)(this.agentX - agentWidth / 2) / 120) == 1)
			{
				yGoal = this.agentY; // don't add DY
				this.agentDY = 0;
			}
			// right corner blocked
			if(map.getType((int)(yGoal - this.agentHeight / 2) / 120, (int)(this.agentX + this.agentWidth / 2) / 120) == 1)
			{
				yGoal = this.agentY; // don't add DY
				this.agentDY = 0;
			}
		}
	}
	
	
	
	// for projectiles and the like
	public Boolean isCollidingWith(Agent rhs)
	{
		Rectangle lhsBox = new Rectangle((int) (agentX - agentWidth / 2), (int) (agentY - agentHeight / 2), agentWidth, agentHeight);
		Rectangle rhsBox = new Rectangle((int) (rhs.getAgentX() - rhs.getAgentWidth() / 2), (int) (rhs.getAgentY() - rhs.getAgentHeight() / 2), rhs.getAgentWidth(), rhs.getAgentHeight());
		return lhsBox.intersects(rhsBox);
	}
	
	
	// all the getters / setters
	// there are so fucking many and honestly most of them are useless
	
	public void setPosition(double x, double y)
	{
		setAgentX(x);
		setAgentY(y);
	}
	
	public void setDirection(double x, double y)
	{
		setAgentDX(x);
		setAgentDY(y);
	}
	
	// sets our player's version of the map coordinates to where the map is moving - basically a synchro function
	public void setMapPos()
	{
		this.mapX = map.getx();
		this.mapY = map.gety();
	}
	
	public void setJumped(Boolean status)
	{
		this.jumped = status;
	}
	
	public Map getMap() {
		return map;
	}

	public int getTileSize() {
		return boxDim;
	}

	public double getMapX() {
		return mapX;
	}

	public double getMapY() {
		return mapY;
	}

	public double getAgentX() {
		return agentX;
	}

	public double getAgentY() {
		return agentY;
	}

	public double getAgentDX() {
		return agentDX;
	}

	public double getAgentDY() {
		return agentDY;
	}


	public int getAgentHeight() {
		return agentHeight;
	}

	public int getAgentWidth() {
		return agentWidth;
	}
	
	public int getThisAction() {
		return thisAction;
	}

	public int getLastAction() {
		return lastAction;
	}

	public Boolean getJumping() {
		return jumping;
	}

	public Boolean getFalling() {
		return falling;
	}

	public int getDirection() {
		return direction;
	}

	public double getMvtSpd() {
		return mvtSpd;
	}

	public double getMvtTer() {
		return mvtTer;
	}

	public double getMvtDec() {
		return mvtDec;
	}

	public double getFallSpd() {
		return fallSpd;
	}

	public double getFallTer() {
		return fallTer;
	}


	public void setMap(Map map) {
		this.map = map;
	}

	public void setMapX(double mapX) {
		this.mapX = mapX;
	}

	public void setMapY(double mapY) {
		this.mapY = mapY;
	}

	public void setAgentX(double agentX) {
		this.agentX = agentX;
	}

	public void setAgentY(double agentY) {
		this.agentY = agentY;
	}

	public void setAgentDX(double agentDX) {
		this.agentDX = agentDX;
	}

	public void setAgentDY(double agentDY) {
		this.agentDY = agentDY;
	}

	public void setAgentHeight(int agentHeight) {
		this.agentHeight = agentHeight;
	}

	public void setAgentWidth(int agentWidth) {
		this.agentWidth = agentWidth;
	}

	public void setThisAction(int thisAction) {
		this.thisAction = thisAction;
	}

	public void setLastAction(int lastAction) {
		this.lastAction = lastAction;
	}

	public void setJumping(Boolean jumping) {
		this.jumping = jumping;
	}

	public void setFalling(Boolean falling) {
		this.falling = falling;
	}

	public void setDirection(int direction) {
		this.direction = direction;
	}

	public void setMvtSpd(double mvtSpd) {
		this.mvtSpd = mvtSpd;
	}

	public void setMvtTer(double mvtTer) {
		this.mvtTer = mvtTer;
	}

	public void setMvtDec(double mvtDec) {
		this.mvtDec = mvtDec;
	}

	public void setFallSpd(double fallSpd) {
		this.fallSpd = fallSpd;
	}

	public void setFallTer(double fallTer) {
		this.fallTer = fallTer;
	}
}
