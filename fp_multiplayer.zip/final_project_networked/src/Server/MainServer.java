package Server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;
import java.util.concurrent.LinkedBlockingDeque;

public class MainServer 
{
	private int numPlayers = 0;
	private int maxPlayers = 2; // temporarily
	private LinkedBlockingDeque<Message> queue = new LinkedBlockingDeque<Message>();
	private Vector<ServerThread> threads = new Vector<ServerThread>();
	
	private ServerSocket ss = null;
	public static void main(String[] args)
	{
		
		MainServer main = new MainServer();
		
	}
	
	public MainServer()
	{
		try
		{	
			// setup socket on port 
			this.ss = new ServerSocket(5768);
			System.out.println("Successfully started the Server on port 5768");
			listen();
		} catch (IOException ioe)
		{
			ioe.printStackTrace();
		}
		listen();
	}
	
	public void listen()
	{
		int count = 0;
		// accept players
		while(this.numPlayers < this.maxPlayers)
		{
			try 
			{
				Socket s = ss.accept();
				System.out.println("User connected");
				ServerThread st = new ServerThread(s, this, count);
				count += 1;
				threads.add(st);
				this.numPlayers += 1;
				System.out.println("num players: " + numPlayers);
			} catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
		
		System.out.println("listening");
		
		while(true) // later replace this with while !gameOver
		{
			int lastnum = 0;
			// wait for all messages to be in
			while(this.queue.size() == 0)
			{
				if(queue.size() > lastnum)
				{
					System.out.println("num messages: " + queue.size());
					lastnum += 1;
				}
				Thread.yield();
			}
			// broadcast messages to all players
			broadcastAllMessages();
			
		}	
	}
	

	// sends all messages to all threads
	public void broadcastAllMessages()
	{
		while(!queue.isEmpty())
		{
			Message message = queue.poll();
			int avoidThread = message.getThread();
			for(int i = 0; i < numPlayers; i++)
			{
				if(i != avoidThread)
				{
					threads.get(i).broadcast(message);
				}
			}
		}
	}
	
	// adds incoming message to queue
	public void appendMessage(Message message)
	{
		this.queue.add(message);
	}
	
}
