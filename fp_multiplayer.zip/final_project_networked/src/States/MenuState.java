package States;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

public class MenuState extends GameState
{
	
	// music
	private Boolean musicPlaying = false;
	private String musicFile = "/music/garden.wav";
	private Clip clip = null;
	
	// graphics
	private BufferedImage background;
	private ArrayList<String> menuOptions= new ArrayList<String>();
	private Color textColor;
	private Font font;
	
	// logic
	private StateManager manager;
	private int cursorIndex = 0;
	
	public MenuState(StateManager manager)
	{
		this.manager = manager;
		setup();
	}

	public void playMusic()
	{
		try{
		    AudioInputStream ais = AudioSystem.getAudioInputStream(getClass().getResource(this.musicFile));
		    clip = AudioSystem.getClip();
		    clip.open(ais);
		    ((FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN)).setValue((float) -15.0);
		    clip.loop(Clip.LOOP_CONTINUOUSLY);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void setup()
	{
		menuOptions.add("Start Game");
		menuOptions.add("Login");
		menuOptions.add("Register");
		menuOptions.add("Quit Game"); // TODO: add more menu options
		try
		{			
			this.textColor = Color.GREEN;
			this.font = new Font("Calibri", Font.PLAIN, 60);
			this.background = ImageIO.read(getClass().getResourceAsStream("/backgrounds/titlescreen.gif"));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void update()
	{
		if(!musicPlaying)
		{
			playMusic();
			musicPlaying = true;
		}
	}
	
	public void draw(Graphics2D graphics) 
	{
		graphics.drawImage(this.background, 0, 0, null);
	
		graphics.setColor(this.textColor);
		graphics.setFont(this.font);
		//graphics.drawString("Coliseum v2 Java Swing", 900, 400); // TODO: centering function
		
		for(int i = 0; i < menuOptions.size(); i++)
		{
			if(i == cursorIndex)
			{
				graphics.setColor(Color.WHITE);
			}
			else
			{
				graphics.setColor(Color.GRAY);
			}
			graphics.drawString(menuOptions.get(i), 100, 500 + i * 100);
		}
	}
	
	private void executeChoice() // select menu option
	{
		if (this.cursorIndex == 0)
		{			
			// connect to socket
			Socket s;
			try {
				s = new Socket("localhost", 5768);
				manager.addTutorial(s);
				manager.setCurrentState(StateManager.TUTORIAL);
				clip.stop();
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		// put your registration / login states here
		
		
		else if(this.cursorIndex == 3)
		{
			System.exit(0);
		}
		// TODO: add more menu options
	}
	
	public void keyPressed(int keyCode)
	{
		if(keyCode == KeyEvent.VK_ENTER) // proceed
		{
			executeChoice();
		}
		if(keyCode == KeyEvent.VK_DOWN) // proceed
		{
			if(this.cursorIndex != this.menuOptions.size() - 1)
			{
				cursorIndex += 1;
			}
		}
		if(keyCode == KeyEvent.VK_UP) // proceed
		{
			if(this.cursorIndex != 0)
			{
				cursorIndex -= 1;
			}
		}
	}
	
	public void keyReleased(int keyCode)
	{
		
	}
}
