import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class RegistrationServer {
	private BufferedReader br;
	private PrintWriter pw;
	
	public RegistrationServer(int port) {
		try {
			System.out.println("Trying to bind to port " + port);
			ServerSocket ss = new ServerSocket(port);
			System.out.println("Registration server bound to port " + port);
			
			while (true) {
				Socket registeringPlayer = ss.accept();
				System.out.println("Registration connection from " + registeringPlayer.getInetAddress());
				
				// every cilent that connects gets a server thread
				RegisteringUserThread rut = new RegisteringUserThread(registeringPlayer, this);
			}
		} catch (IOException ioe) {
			System.out.println("ioe in RegistrationServer constructor: " + ioe.getMessage());
		}
	}
	
	public void register(String username, String password, RegisteringUserThread registeringUser) {
		System.out.println("Registering user with:");
		System.out.println("Username = " + username);
		System.out.println("Password = " + password);
		System.out.println();
		
		// add user to database
		
		String registrationMessage = "TEMPORARY SUCCESS MESSAGE";
		
		// if registration was success, give a success message, else give a failure message
		registeringUser.notifyRegistrationStatus(registrationMessage);
	}
	
	public static void main(String[] args) {
		RegistrationServer cr = new RegistrationServer(6789);
	}
}
