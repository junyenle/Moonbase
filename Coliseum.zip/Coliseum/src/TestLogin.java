import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class TestLogin {

	public static void main(String[] args) {
		try {
			Socket logginSocket = new Socket("localhost", 6788);
			
			PrintWriter pw = new PrintWriter(logginSocket.getOutputStream(), true);
			BufferedReader br = new BufferedReader(new InputStreamReader(logginSocket.getInputStream()));
			
			pw.println("donaldJ");
			pw.println("f");
			pw.flush();
			
			String loginMessage = null;
			while (loginMessage == null) {
				loginMessage = br.readLine();
				Thread.yield();
			}
			
			System.out.println(loginMessage);
			
			if (loginMessage.equals("LOGIN SUCCESS")) {
				while (!loginMessage.equals("asdf")) {
					Thread.yield();
				}
			}
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
