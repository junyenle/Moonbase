import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class TestLogin {

	public static void main(String[] args) {
		try {
			Socket logginSocket = new Socket("localhost", 6788);
			
			PrintWriter out = new PrintWriter(logginSocket.getOutputStream(), true);
			out.println("jesus christ");
			out.println("attemptedPassword");
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
