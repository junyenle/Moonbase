import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ActiveUserServer {
	List<ActiveUserThread> activeUserThreads;
	
	public ActiveUserServer(int port) {
		try {
			System.out.println("Trying to bind to port " + port);
			ServerSocket ss = new ServerSocket(port);
			System.out.println("Login server bound to port " + port);
			
			activeUserThreads = new ArrayList<ActiveUserThread>();
			
			// loop to keep accepting logins
			while (true) {
				Socket loggingInPlayer = ss.accept();
				System.out.println("Login connection from " + loggingInPlayer.getInetAddress());
				
				// every cilent that connects gets a server thread
				ActiveUserThread activeUser = new ActiveUserThread(loggingInPlayer, this);
				
				if (activeUser.login()) {
					activeUserThreads.add(activeUser);
					System.out.println("Just logged in " + activeUser.getUsername());
					System.out.println("There are now " + activeUserThreads.size() + " logged in users.");
				}
			}
		} catch (IOException ioe) {
			System.out.println("ioe in LoginServer constructor: " + ioe.getMessage());
		}
	}
	
	public static void main(String[] args) {
		ActiveUserServer ls = new ActiveUserServer(6788);
	}
}
