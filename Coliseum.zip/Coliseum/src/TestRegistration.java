import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class TestRegistration {
	public static void main(String[] args) {
		try {
			Socket registeringUserSocket = new Socket("localhost", 6789);
			
			PrintWriter out = new PrintWriter(registeringUserSocket.getOutputStream(), true);
			out.println("second user");
			out.println("new pass");
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
