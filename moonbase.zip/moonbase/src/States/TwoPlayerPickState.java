package States;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Vector;

import javax.imageio.ImageIO;

import Agents.GravWall;

public class TwoPlayerPickState extends GameState
{

	
	// graphics
	private BufferedImage background;
	private ArrayList<String> menuOptions= new ArrayList<String>();
	private Color textColor;
	private Font font;
	private Boolean loaded = false;
	private Boolean needWaitMessage = false;
	
	// logic
	private StateManager manager;
	private int cursorIndex = 0;
	
	public TwoPlayerPickState(StateManager manager)
	{
		this.manager = manager;
		setup();
	}

	
	public void setup()
	{
		if(!loaded)
		{
			menuOptions.add("1P Game");
			menuOptions.add("2P Game");
			menuOptions.add("Quit Game"); // TODO: add more menu options
			try
			{			
				this.textColor = Color.GREEN;
				this.font = new Font("Calibri", Font.PLAIN, 60);
				this.background = ImageIO.read(getClass().getResourceAsStream("/backgrounds/titlescreen.png"));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			loaded = true;
		}
	}
	
	public void update()
	{
		
	}
	
	public void draw(Graphics2D graphics) 
	{
		graphics.drawImage(this.background, 0, 0, null);
	
		graphics.setColor(this.textColor);
		graphics.setFont(this.font);
		//graphics.drawString("Coliseum v2 Java Swing", 900, 400); // TODO: centering function
		
		if(needWaitMessage)
		{
			graphics.setColor(Color.WHITE);
			manager.getGraphics().drawString("Waiting for a friend...", 100, 600);
			return;
		}
		
		for(int i = 0; i < menuOptions.size(); i++)
		{
			if(i == cursorIndex)
			{
				graphics.setColor(Color.WHITE);
			}
			else
			{
				graphics.setColor(Color.GRAY);
			}
			graphics.drawString(menuOptions.get(i), 100, 500 + i * 100);
		}

	}
	
	private void executeChoice() // select menu option
	{
		// 1P Game
		if (this.cursorIndex == 0)
		{
			manager.setCurrentState(StateManager.ONEPGAME);
			manager.stopMusic("menu");
		}
			
		// 2P Game
		else if (this.cursorIndex == 1)
		{			
			
			// draw
			needWaitMessage = true;
			
			// connect to socket
			Socket s;
			try {
				s = new Socket(manager.host, 5768);
				manager.addTwoP(s); // make new 2p game
				manager.setCurrentState(StateManager.TWOPGAME);
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		// put your registration / login states here
		
		
		else if(this.cursorIndex == 2)
		{
			System.exit(0);
		}
		// TODO: add more menu options
	}
	
	public void keyPressed(int keyCode)
	{
		if(keyCode == KeyEvent.VK_ENTER) // proceed
		{
			executeChoice();
		}
		if(keyCode == KeyEvent.VK_DOWN) // proceed
		{
			if(this.cursorIndex != this.menuOptions.size() - 1)
			{
				cursorIndex += 1;
			}
		}
		if(keyCode == KeyEvent.VK_UP) // proceed
		{
			if(this.cursorIndex != 0)
			{
				cursorIndex -= 1;
			}
		}
	}
	
	public void keyReleased(int keyCode)
	{
		
	}
}
