package States;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Stack;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

import Agents.Checkpoint;
import Agents.DeathBar;
import Agents.GravWall;
import Agents.NPC;
import Agents.Player;
import Agents.Position;
import Agents.Spaceship;
import Driver.GameWindow;
import Maps.Map;


public class TwoPGame extends GameState
{

	Vector<NPC> npcs = new Vector<NPC>();
	
	private Spaceship spaceship;
	private Boolean backToEarth = false;
	private int frameCount = 0;
	
	// gravwalls
	private Vector<GravWall> gravwalls = new Vector<GravWall>();
	
	private DeathBar death;
	
	private Player player;
	private Player friend;
	private BufferedImage background;
	private Map map;
	protected StateManager manager;
	private Socket socket;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private int playerNo;
	private Boolean initialSet = false;
	private Checkpoint testPoint;
	private Checkpoint realPoint;
	private Stack<Position> cpStack = new Stack<Position>();
	private Boolean reset = false;
	
	// data management
	private DataOutputStream dos;
	private DataInputStream dis;
	
	// music
	private Boolean musicPlaying = false;
	private String musicFile = "/music/fungal.wav";
	private Clip clip = null;
	
	public TwoPGame(StateManager manager, Socket s)
	{
		this.socket = s;
		
		try {
			this.oos = new ObjectOutputStream(this.socket.getOutputStream());
			this.ois = new ObjectInputStream(this.socket.getInputStream());
			this.dos = new DataOutputStream(this.socket.getOutputStream());
			this.dis = new DataInputStream(this.socket.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		this.manager = manager;
		setup(); // level setup
	}
	
	public void playMusic()
	{
		try{
			manager.stopMusic("menu");
		    manager.playMusic("level");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void setup()
	{
		//map = new Map("/tiles/leveltiles.gif", "/maps/twopmap.txt");
		map = new Map("/tiles/leveltiles.png", "/maps/onemap.txt");
		this.player = new Player(map);
		this.friend = new Player(map);
		this.testPoint = new Checkpoint(2100, 660 + 1320 + 90, 0, map);
		this.realPoint = new Checkpoint(105 * 120, 23 * 120 + 30, 1, map);
		this.death = new DeathBar(2760 + 4 * 120);
		
		this.spaceship = new Spaceship(15700, 750, map);
		

		npcs.add(new NPC(700, 2580, "Today's the big day, huh.", false, 40, 200, map));
		//npcs.add(new NPC(2400, 2580 - 5 * 120, "Be safe. Be well.", true, 20, 250, map));
		npcs.add(new NPC(4100, 2580, "Be safe. Be well.", true, 10, 200, map));
		npcs.add(new NPC(5100, 2580, "Four more years and I'll be in your shoes.", true, 20, 300, map));
		npcs.add(new NPC(6675, 2580 - 120, "A cup before you go?", false, 20, 200, map));
		npcs.add(new NPC(7850, 2580 - 4 * 120, "Careful out there in the open.", false, 20, 200, map));
		npcs.add(new NPC(7300, 2580 - 9 * 120, "These things don't maintain themselves, y'know.", true, 10, 300, map));
		npcs.add(new NPC(13700, 2580 - 12 * 120, "I never knew Planet Earth was so blue.", false, 0, 0, map));
		npcs.add(new NPC(12000, 2580 - 4 * 120, "Nobody ever comes out here except to leave.", true, 20, 200, map));

		try {
			this.background = ImageIO.read(getClass().getResourceAsStream("/backgrounds/moonground.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void update()
	{
		if(!initialSet)
		{
			try {
				int messageLength = dis.readInt();
				byte[] message = new byte[messageLength];
				dis.readFully(message, 0,  message.length);
				this.playerNo = Integer.valueOf(new String(message));
				System.out.println("received message in initial set: " + playerNo);
				
				if(playerNo == 1)
				{
					player.setPosition(700, 1200 + 1320);
					friend.setPosition(900, 1200 + 1320);
					cpStack.add(new Position(700, 1200 + 1320));
				}
				else if(playerNo == 2)
				{
					player.setPosition(900,  1200 + 1320);
					friend.setPosition(700, 1200 + 1320);
					cpStack.add(new Position(900,  1200 + 1320));
				}
				
				gravwalls.add(new GravWall(8210,2160, 6, 30));
				gravwalls.add(new GravWall(8110, 2160, 10, 50));
				gravwalls.add(new GravWall(8110 + 3480, 2160, 6, 30));
				gravwalls.add(new GravWall(8210 + 3480, 2160, 10, 50));
				gravwalls.add(new GravWall(8110 + 3480 + 1200, 2160 + 600, 6, 30));
				gravwalls.add(new GravWall(8110 + 3480 + 960, 2160 + 600, 10, 50));
				
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			initialSet = true;
		}
		if(!musicPlaying)
		{
			playMusic();
			musicPlaying = true;
		}
		if(this.reset == true && !cpStack.isEmpty())
		{
			player.setPosition(cpStack.peek().getX(), cpStack.peek().getY() - 100);
			this.reset = false;
		}
		
		for(GravWall gravwall: gravwalls)
		{
			if(player.isCollidingWith(gravwall))
			{
				player.setFallSpd(gravwall.getGravity());
				player.setFallTer(gravwall.getGravter());
			}
		}
		
		for (NPC npc : npcs) {
			npc.update();
		}
		
		if(backToEarth == true)
		{
			frameCount += 1;
			if(frameCount == 47)
			{
				manager.setCurrentState(StateManager.GAMEOVER);
				manager.stopMusic("level");
				manager.playMusic("gameover");
			}
			return;
		}
				
		player.update(this.friend); // update player data
		map.setPosition(GameWindow.WIDTH / 2 - player.getAgentX(), GameWindow.HEIGHT / 2 - player.getAgentY() + 100); // set the camera position

		// now broadcast the updated info to the socket
		try {
			short dxshort = 0;
			short dyshort = 0;
			if(player.getAgentDX() > 0)
			{
				dxshort = 1;
			}
			else if(player.getAgentDX() < 0)
			{
				dxshort = -1;
			}
			if(player.getAgentDY() > 0)
			{
				dyshort = 1;
			}
			else if(player.getAgentDY() < 0)
			{
				dyshort = -1;
			}

			String playerPos = String.valueOf((int)player.getAgentX()) + "|";
			playerPos += String.valueOf((int)player.getAgentY()) + "|";
			playerPos += String.valueOf((int)player.getState()) + "|";
			playerPos += String.valueOf(dxshort) + "|";
			playerPos += String.valueOf(dyshort);
			//this.oos.writeObject(new PlayerPos((short)player.getAgentX(), (short)player.getAgentY(), (short)player.getState(), dxshort, dyshort));
			//oos.flush();
			byte[] bytePos = playerPos.getBytes();
			dos.writeInt(bytePos.length);
			dos.write(bytePos);
			dos.flush();
			
			Thread.yield();
			//System.out.println("waiting for server response");
			
			int length = dis.readInt();
			byte[] positionMessage = new byte[length];
			dis.readFully(positionMessage, 0, positionMessage.length);
			
			String positionString = new String(positionMessage);
			//System.out.println("Received string in position set: " + positionString);
			String[] positions = positionString.split("\\|");
			
			//System.out.println("received server response");
			// draw based on the message
			// create temp player
			this.friend.setPosition(Integer.valueOf(positions[0]), Integer.valueOf(positions[1]));
			this.friend.setState(Integer.valueOf(positions[2]));
			this.friend.setAgentDX(Integer.valueOf(positions[3]));
			this.friend.setAgentDY(Integer.valueOf(positions[4]));
			//System.out.println("state: " + message.getState());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		if(friend.isCollidingWith(testPoint) && testPoint.getFlag() == 0)
		{
			player.setPosition(friend.getAgentX() - friend.getAgentWidth(), friend.getAgentY());
			cpStack.add(new Position(testPoint.getAgentX(), testPoint.getAgentY()));
			testPoint.setFlag(1);
		}
		if(player.isCollidingWith(testPoint) && testPoint.getFlag() == 0)
		{
			cpStack.add(new Position(testPoint.getAgentX(), testPoint.getAgentY()));
			testPoint.setFlag(1);
		}
		
		if(friend.isCollidingWith(realPoint) && realPoint.getFlag() == 0)
		{
			player.setPosition(friend.getAgentX() - friend.getAgentWidth(), friend.getAgentY());
			cpStack.add(new Position(realPoint.getAgentX(), realPoint.getAgentY()));
			realPoint.setFlag(1);
		}
		if(player.isCollidingWith(realPoint) && realPoint.getFlag() == 0)
		{
			cpStack.add(new Position(realPoint.getAgentX(), realPoint.getAgentY()));
			realPoint.setFlag(1);
		}
		
		if(player.isCollidingWith(death))
		{
			player.setPosition(cpStack.peek().getX(), cpStack.peek().getY() - 100);
		}
		
		if(player.isCollidingWith(spaceship))
		{
			System.out.println("player is colliding with ss");
		}
		else
		{
			System.out.println("player is NOT COLLIDING with ss");
		}
		
		if(player.isCollidingWith(spaceship) && friend.isCollidingWith(spaceship))
		{
			System.out.println("double collision");
			backToEarth = true;
			spaceship.setMoving(true);
		}
		
		for(NPC npc: npcs)
		{
			if(player.isCollidingWith(npc) || friend.isCollidingWith(npc))
			{
				npc.setDisplayText(true);
			}
			else
			{
				npc.setDisplayText(false);
			}
		}
		
	}
	
	public void draw(Graphics2D graphics)
	{
		graphics.drawImage(this.background, 0, 0, null);
		this.map.draw(graphics); // then the map tiles
		
		for (NPC npc : npcs) 
		{
			try {
			npc.draw(graphics);
			} catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		
		if(!backToEarth)
		{	
			this.friend.draw(graphics); // draw friend
			this.player.draw(graphics); // then the player
			/*graphics.setColor(Color.GRAY);
			graphics.setFont(new Font("Calibri", Font.PLAIN, 20));
			graphics.drawString("you", (int)player.getAgentX() + map.getX() - 5, (int)player.getAgentY() + map.getY() - 15 - (int)(player.getAgentHeight() / 2));*/
		}
		this.testPoint.draw(graphics);
		this.realPoint.draw(graphics);
		this.spaceship.draw(graphics);
	}
	
	public void keyPressed(int keyCode)
	{
		if(keyCode == KeyEvent.VK_ESCAPE)
		{
			player.setState(0);
			System.exit(0);
		}
		if(keyCode == KeyEvent.VK_LEFT)
		{
			player.setState(0);
			player.setAgentDX(0);
			player.setDirection(2); // left
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			player.setState(0);
			player.setAgentDX(0);
			player.setDirection(1); // right
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			player.setState(0);
			player.setJumping(true); // + DY
		}
	}
	
	public void keyReleased(int keyCode)
	{
		
		if(keyCode == KeyEvent.VK_LEFT)
		{
			player.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			player.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			player.setJumping(false); // no more + DY
			player.setJumped(true); // can't jump again
		}
		if(keyCode == KeyEvent.VK_DOWN)
		{
			//player.nextState();
			this.reset = true;
		}
	}
	
	
	
	
}
