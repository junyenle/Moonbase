package Agents;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import Maps.Map;

public class NPC extends Agent{
	
	private String message;
	private ArrayList<BufferedImage> animationFrames = new ArrayList<BufferedImage>();
	private Boolean moving = false;
	private int moveFrames;	
	private int moveCount = 0;
	private double moveSpeed = 5;
	private int animationFrame = 0;
	private Boolean canMove;
	private int idleFrames;
	private Boolean displayText = false;
	private int afterLeaving = 90;
	
	public NPC(double x, double y, String text, Boolean canMove, int moveFrames, int idleFrames, Map map)
	{
		this.idleFrames = idleFrames;
		this.map = map;
		this.agentWidth = 60;
		this.agentHeight = 118;
		this.agentDX = moveSpeed;
		this.agentDY = 0;
		this.agentX = x;
		this.agentY = y;
		this.canMove = canMove;
		this.message = text;
		this.moveFrames = moveFrames;
		setup();
	}
	
	public void setDisplayText(Boolean b)
	{
		// if setting from true to false
		if(this.displayText == true && b == false)
		{
			// start our counter
			afterLeaving = 0;
		}
		this.displayText = b;
	}
	
	public void setup()
	{
		
		// animations
		try
		{
			BufferedImage spriteSheet = ImageIO.read(getClass().getResourceAsStream("/sprites/npcsprites.gif"));
			animationFrames.add(spriteSheet.getSubimage(0, 0, 120, 120)); // standing
			animationFrames.add(spriteSheet.getSubimage(0, 120, 120, 120)); // RIGHT
			animationFrames.add(spriteSheet.getSubimage(0, 240, 120, 120)); // LEFT	
		} catch (IOException e)
		{
			// do nothing
		}
	}
	
	public void update()
	{
		if(!canMove)
		{
			animationFrame = 0;
			return;
		}
		
		moveCount += 1;
		
		if(moveCount >= moveFrames && moving) // if moving and expired frames
		{
			moving = false;
			agentDX = -agentDX;
			moveCount = 0;
		}
		else if(moveCount >= idleFrames && !moving) // if not moving and expired frames
		{
			moving = true;
			moveCount = 0;
		}
		
		if(moving)
		{
			if(agentDX > 0) // right
			{
				animationFrame = 1;
			}
			else if(agentDX < 0) // left
			{
				animationFrame = 2;
			}
			agentX += agentDX;
		}
		else
		{
			animationFrame = 0;
		}
	}
	
	public void draw(Graphics2D graphics)
	{
		this.mapX = map.getX();
		this.mapY = map.getY();
		graphics.drawImage(animationFrames.get(animationFrame), (int) (this.agentX + this.mapX - this.agentWidth / 2), (int) (this.agentY + this.mapY - this.agentHeight / 2), null);
		if(displayText || afterLeaving < 35)
		{
			graphics.setColor(Color.GRAY);
			graphics.setFont(new Font("Calibri", Font.PLAIN, 20));
			graphics.drawString(message, (int) (agentX + mapX - (graphics.getFontMetrics().stringWidth(message))/2 + 5), (int) (agentY + mapY - 15 - agentHeight / 2));
		}
		
		afterLeaving += 1;
		
		if(afterLeaving == 100)
		{
			afterLeaving = 40;
		} // so we dont overflow
	}
	
	

}
