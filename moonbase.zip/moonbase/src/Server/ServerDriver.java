package Server;

import DatabaseServer.ActiveUserServer;
import DatabaseServer.RegistrationServer;

public class ServerDriver {
	public static void main(String[] args)
	{
		ActiveUserServer aus = new ActiveUserServer(6788);
		RegistrationServer cr = new RegistrationServer(6798);
		MainServer main = new MainServer(5768);	
	}
}
