package Server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;

public class ServerThread extends Thread implements Serializable
{

	private static final long serialVersionUID = 1L;
	private MainServer server;
	private Socket socket;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private int id;
	private DataInputStream dis;
	private DataOutputStream dos;
	
	public ServerThread(Socket s, MainServer ms, int id) 
	{
		Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
		this.socket = s;
		this.server = ms;
		this.id = id;
		
		try 
		{
			this.ois = new ObjectInputStream(this.socket.getInputStream());
			this.oos = new ObjectOutputStream(this.socket.getOutputStream());
			this.dis = new DataInputStream(this.socket.getInputStream());
			this.dos = new DataOutputStream(this.socket.getOutputStream());
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
		
		this.start();
	}
	
	public void run()
	{
		while(true)
		{
			try {
				int length = dis.readInt();
				byte[] message = new byte[length];
				dis.readFully(message, 0, message.length);
				String messageText = new String(message);
				String fullMessageText = String.valueOf(this.id) + messageText;
				
				this.server.appendMessage(fullMessageText);
			} catch (IOException e) {
				break;
			}
		}
	}
	
	public void broadcast(String message)
	{
		try 
		{
			byte[] bytemessage = message.getBytes();
			dos.writeInt(message.length());
			dos.write(bytemessage);
			dos.flush();
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	
	
}
