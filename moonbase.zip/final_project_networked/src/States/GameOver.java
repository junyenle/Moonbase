package States;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class GameOver extends GameState{
	private BufferedImage background;
	private BufferedImage background2;
	private BufferedImage background3;
	private BufferedImage background4;
	private StateManager manager;
	private int aniCounter = 0;
	
	public GameOver(StateManager stateManager)
	{
		this.manager = stateManager;
	}
	
	@Override
	public void setup() {
		// TODO Auto-generated method stub
		try {
			this.background = ImageIO.read(getClass().getResourceAsStream("/backgrounds/gameover.png"));
			this.background2 = ImageIO.read(getClass().getResourceAsStream("/backgrounds/gameover2.png"));
			this.background3 = ImageIO.read(getClass().getResourceAsStream("/backgrounds/gameover3.png"));
			this.background4 = ImageIO.read(getClass().getResourceAsStream("/backgrounds/gameover4.png"));			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void update() {
		
		
	}

	@Override
	public void draw(Graphics2D graphics) {
		if(aniCounter < 5)
		{
			graphics.drawImage(this.background, 0, 0, null);
		}
		else if(aniCounter < 10)
		{
			graphics.drawImage(this.background2, 0, 0, null);
		}
		else if(aniCounter < 15)
		{
			graphics.drawImage(this.background3, 0, 0, null);
		}
		else if(aniCounter < 20)
		{
			graphics.drawImage(this.background4, 0, 0, null);
			if(aniCounter == 19)
			{
				aniCounter = 1;
			}
		}
		aniCounter += 1;
		
	}

	@Override
	public void keyPressed(int keyCode) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(int keyCode) {
		// TODO Auto-generated method stub
		
	}
	

}
