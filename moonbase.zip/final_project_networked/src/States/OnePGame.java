package States;

import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

import Agents.Checkpoint;
import Agents.DeathBar;
import Agents.GravWall;
import Agents.SoloPlayer;
import Agents.Spaceship;
import Driver.GameWindow;
import Maps.Map;


public class OnePGame extends GameState
{

	private Spaceship spaceship;
	
	// gravwalls
	private Vector<GravWall> gravwalls = new Vector<GravWall>();
	
	private DeathBar death;
	
	private SoloPlayer player;
	private BufferedImage background;
	private Map map;
	protected StateManager manager;
	
	private Checkpoint testPoint;
	private Checkpoint realPoint;
	
	private long frameCount = 0;
	
	// music
	private Boolean musicPlaying = false;
	private String musicFile = "/music/fungal.wav";
	private Clip clip = null;

	private boolean drawPlayer = true;
	
	public OnePGame(StateManager manager)
	{
		this.manager = manager;
		setup(); // level setup
	}
	
	public void playMusic()
	{
		try{
		    AudioInputStream ais = AudioSystem.getAudioInputStream(getClass().getResource(this.musicFile));
		    clip = AudioSystem.getClip();
		    clip.open(ais);
		    ((FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN)).setValue((float) -5.0);
		    clip.loop(Clip.LOOP_CONTINUOUSLY);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void setup()
	{
		map = new Map("/tiles/leveltiles.png", "/maps/onemap.txt");
		this.player = new SoloPlayer(map);
		this.testPoint = new Checkpoint(1700,1260 + 1320 + 90, 0, map);
		this.realPoint = new Checkpoint(111 * 120, 23 * 120 + 30, 1, map);
		player.setPosition(1100, 500 + 1320);
		
		gravwalls.add(new GravWall(8210,2160, 6, 30));
		gravwalls.add(new GravWall(8110, 2160, 10, 50));
		gravwalls.add(new GravWall(8110 + 3480, 2160, 6, 30));
		gravwalls.add(new GravWall(8210 + 3480, 2160, 10, 50));
		gravwalls.add(new GravWall(8110 + 3480 + 1200, 2160 + 600, 6, 30));
		gravwalls.add(new GravWall(8110 + 3480 + 960, 2160 + 600, 10, 50));
		
		this.death = new DeathBar(2760 + 4 * 120);
		
		this.spaceship = new Spaceship(15700, 750, map);
		
		
		
		try {
			this.background = ImageIO.read(getClass().getResourceAsStream("/backgrounds/moonground.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void update()
	{
		if(drawPlayer == false)
		{
			frameCount += 1;
		}
		if(frameCount == 47)
		{
			manager.setCurrentState(StateManager.GAMEOVER);
		}
		
		if(player.isCollidingWith(spaceship))
		{
			// turn off drawing
			drawPlayer = false;
			spaceship.setMoving(true);
		}
		if(!musicPlaying)
		{
			playMusic();
			musicPlaying = true;
		}
		
		for(GravWall gravwall: gravwalls)
		{
			if(player.isCollidingWith(gravwall))
			{
				player.setFallSpd(gravwall.getGravity());
				player.setFallTer(gravwall.getGravter());
			}
		}
		
		player.update(); // update player data
		if(player.isCollidingWith(testPoint))
		{
			if(testPoint.getFlag() == 0)
			{
				player.setPosition(2160, 660 + 1320);
			}
			//testPoint.setFlag(1);
		}
		if(player.isCollidingWith(realPoint))
		{
			if(realPoint.getFlag() == 0)
			{
				player.setPosition(realPoint.getAgentX() + 9 * 120, realPoint.getAgentY() - 9 * 120);
			}
			//realPoint.setFlag(1);
		}
		
		if(player.isCollidingWith(death))
		{
			if(realPoint.getFlag() == 0)
			{
				player.setPosition(realPoint.getAgentX() - 200, realPoint.getAgentY() - 100);
			}
			//realPoint.setFlag(1);
		}
		
		map.setPosition(GameWindow.WIDTH / 2 - player.getAgentX(), GameWindow.HEIGHT / 2 - player.getAgentY() + 100); // set the camera position
	}
	
	public void draw(Graphics2D graphics)
	{
		graphics.drawImage(this.background, 0, 0, null);
		this.map.draw(graphics); // then the map tiles
		if(drawPlayer)
		{
			this.player.draw(graphics); // then the player
		}
		this.testPoint.draw(graphics);
		this.realPoint.draw(graphics);
		this.spaceship.draw(graphics);
	}
	
	public void keyPressed(int keyCode)
	{
		if(keyCode == KeyEvent.VK_ESCAPE)
		{
			clip.stop();
			musicPlaying = false;
			manager.setCurrentState(0);
			manager.playMenuMusic();
		}
		if(keyCode == KeyEvent.VK_LEFT)
		{
			if(drawPlayer == false)
			{
				return;
			}
			player.setState(0);
			player.setAgentDX(0);
			player.setDirection(2); // left
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			if(drawPlayer == false)
			{
				return;
			}
			player.setState(0);
			player.setAgentDX(0);
			player.setDirection(1); // right
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			if(drawPlayer == false)
			{
				return;
			}
			player.setState(0);
			player.setJumping(true); // + DY
		}
		if(keyCode == KeyEvent.VK_T)
		{
			
			manager.setCurrentState(StateManager.GAMEOVER);
		}
	}
	
	public void keyReleased(int keyCode)
	{
		
		if(keyCode == KeyEvent.VK_LEFT)
		{
			player.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			player.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			player.setJumping(false); // no more + DY
			player.setJumped(true); // can't jump again
		}
		if(keyCode == KeyEvent.VK_DOWN)
		{
			// TODO: get rid of this
			player.setPosition(13000, 2000);
		}
	}
	
	
	
	
}
