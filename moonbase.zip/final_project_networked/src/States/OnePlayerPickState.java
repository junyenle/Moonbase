package States;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

public class OnePlayerPickState extends GameState
{
	
	// music
	private Boolean musicPlaying = false;
	private String musicFile = "/music/garden.wav";
	private Clip clip = null;
	
	// graphics
	private BufferedImage background;
	private ArrayList<String> menuOptions= new ArrayList<String>();
	private Color textColor;
	private Font font;
	private Boolean loaded = false;
	
	// logic
	private StateManager manager;
	private int cursorIndex = 0;
	
	public OnePlayerPickState(StateManager manager)
	{
		this.manager = manager;
		setup();
	}
	
	public void setup()
	{
		if(!loaded)
		{
			menuOptions.add("1P Game");
			menuOptions.add("Quit Game"); // TODO: add more menu options
			try
			{			
				this.textColor = Color.GREEN;
				this.font = new Font("Calibri", Font.PLAIN, 60);
				this.background = ImageIO.read(getClass().getResourceAsStream("/backgrounds/titlescreen.png"));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			loaded = true;
		}
	}
	
	public void draw(Graphics2D graphics) 
	{
		graphics.drawImage(this.background, 0, 0, null);
	
		graphics.setColor(this.textColor);
		graphics.setFont(this.font);
		//graphics.drawString("Coliseum v2 Java Swing", 900, 400); // TODO: centering function
		
		for(int i = 0; i < menuOptions.size(); i++)
		{
			if(i == cursorIndex)
			{
				graphics.setColor(Color.WHITE);
			}
			else
			{
				graphics.setColor(Color.GRAY);
			}
			graphics.drawString(menuOptions.get(i), 100, 500 + i * 100);
		}
	}
	
	private void executeChoice() // select menu option
	{
		// 1P Game
		if (this.cursorIndex == 0)
		{
			manager.setCurrentState(StateManager.ONEPGAME);
			manager.stopMusic("menu");
		}
		
		
		else if(this.cursorIndex == 1)
		{
			System.exit(0);
		}
		// TODO: add more menu options
	}
	
	public void keyPressed(int keyCode)
	{
		if(keyCode == KeyEvent.VK_ENTER) // proceed
		{
			executeChoice();
		}
		if(keyCode == KeyEvent.VK_DOWN) // proceed
		{
			if(this.cursorIndex != this.menuOptions.size() - 1)
			{
				cursorIndex += 1;
			}
		}
		if(keyCode == KeyEvent.VK_UP) // proceed
		{
			if(this.cursorIndex != 0)
			{
				cursorIndex -= 1;
			}
		}
	}
	
	public void keyReleased(int keyCode)
	{
		
	}

	@Override
	public void update() 
	{	
		
	}
}
