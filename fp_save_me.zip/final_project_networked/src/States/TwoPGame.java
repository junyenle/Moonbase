package States;

import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Stack;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

import Agents.Player;
import Driver.GameWindow;
import Maps.Map;
import Server.PlayerPos;


public class TwoPGame extends GameState
{
	private Player player;
	private Player friend;
	private BufferedImage background;
	private Map map;
	protected StateManager manager;
	private Socket socket;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private int playerNo;
	private Boolean initialSet = false;
	
	// data management
	private Stack<PlayerPos> positionStack = new Stack<PlayerPos>();
	
	// music
	private Boolean musicPlaying = false;
	private String musicFile = "/music/fungal.wav";
	private Clip clip = null;
	
	public TwoPGame(StateManager manager, Socket s)
	{
		this.socket = s;
		
		try {
			this.oos = new ObjectOutputStream(this.socket.getOutputStream());
			this.ois = new ObjectInputStream(this.socket.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		this.manager = manager;
		setup(); // level setup
	}
	
	public void playMusic()
	{
		try{
			manager.stopMenuMusic();
		    AudioInputStream ais = AudioSystem.getAudioInputStream(getClass().getResource(this.musicFile));
		    clip = AudioSystem.getClip();
		    clip.open(ais);
		    ((FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN)).setValue((float) -15.0);
		    clip.loop(Clip.LOOP_CONTINUOUSLY);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void setup()
	{
		map = new Map("/tiles/leveltiles.gif", "/maps/twopmap.txt");
		this.player = new Player(map);
		this.friend = new Player(map);

		try {
			this.background = ImageIO.read(getClass().getResourceAsStream("/backgrounds/mountains.gif"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void update()
	{
		if(!initialSet)
		{
			try {
				PlayerPos playerNumMessage = (PlayerPos)ois.readObject();
				playerNo = playerNumMessage.getState(); // just reusing PlayerPos object
				if(playerNo == 1)
				{
					player.setPosition(1100, 500);
					friend.setPosition(900, 500);
				}
				else if(playerNo == 2)
				{
					player.setPosition(900,  500);
					friend.setPosition(1100, 500);
				}
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			initialSet = true;
		}
		if(!musicPlaying)
		{
			playMusic();
			musicPlaying = true;
		}
		player.update(this.friend); // update player data
		map.setPosition(GameWindow.WIDTH / 2 - player.getAgentX(), GameWindow.HEIGHT / 2 - player.getAgentY()); // set the camera position

		// now broadcast the updated info to the socket
		try {
			this.oos.writeObject(new PlayerPos(player.getAgentX(), player.getAgentY(), player.getState(), player.getAgentDX(), player.getAgentDY()));
			oos.flush();
			//System.out.println("waiting for server response");
			PlayerPos message = (PlayerPos)this.ois.readObject();
			//System.out.println("received server response");
			// draw based on the message
			// create temp player
			this.friend.setPosition(message.getX(), message.getY());
			this.friend.setState(message.getState());
			this.friend.setAgentDX(message.getDX());
			this.friend.setAgentDY(message.getDY());
			//System.out.println("state: " + message.getState());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public void draw(Graphics2D graphics)
	{
		graphics.drawImage(this.background, 0, 0, null);
		this.map.draw(graphics); // then the map tiles
		this.player.draw(graphics); // then the player
		this.friend.draw(graphics); // draw friend
	}
	
	public void keyPressed(int keyCode)
	{
		if(keyCode == KeyEvent.VK_ESCAPE)
		{
			player.setState(0);
			System.exit(0);
		}
		if(keyCode == KeyEvent.VK_LEFT)
		{
			player.setState(0);
			player.setAgentDX(0);
			player.setDirection(2); // left
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			player.setState(0);
			player.setAgentDX(0);
			player.setDirection(1); // right
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			player.setState(0);
			player.setJumping(true); // + DY
		}
	}
	
	public void keyReleased(int keyCode)
	{
		
		if(keyCode == KeyEvent.VK_LEFT)
		{
			player.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			player.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			player.setJumping(false); // no more + DY
			player.setJumped(true); // can't jump again
		}
		if(keyCode == KeyEvent.VK_DOWN)
		{
			player.nextState();
		}
	}
	
	
	
	
}
