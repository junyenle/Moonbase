package Server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;

public class ServerThread extends Thread implements Serializable
{
	private MainServer server;
	private Socket socket;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private int id;
	
	public ServerThread(Socket s, MainServer ms, int id) 
	{
		this.socket = s;
		this.server = ms;
		this.id = id;
		
		try 
		{
			this.ois = new ObjectInputStream(this.socket.getInputStream());
			this.oos = new ObjectOutputStream(this.socket.getOutputStream());
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
		
		this.start();
	}
	
	public void run()
	{
		while(true)
		{
			try {
				PlayerPos incomingMessage = (PlayerPos)this.ois.readObject();
				incomingMessage.setThread(this.id);
				this.server.appendMessage(incomingMessage);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				break;
			}
		}
	}
	
	public void broadcast(PlayerPos message)
	{
		try 
		{
			this.oos.writeObject(message);
			this.oos.flush();
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	
	
}
