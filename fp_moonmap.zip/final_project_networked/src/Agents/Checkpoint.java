package Agents;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import Maps.Map;

public class Checkpoint extends Agent
{
	private int flagged = 0;
	private int cpNum;
	private BufferedImage[] flagSprites = new BufferedImage[2];
	private Map map;
	
	public Checkpoint(double x, double y, int cpNum, Map map)
	{
		this.setPosition(x, y);
		this.agentDX = 0;
		this.agentDY = 0;
		this.agentWidth = 120;
		this.agentHeight = 120;
		this.cpNum = cpNum;
		this.map = map;

		readAnimations();
	}
	
	public void setFlag(int flagged)
	{
		this.flagged = flagged;
	}
	
	public int getFlag()
	{
		return this.flagged;
	}
	
	public void readAnimations() // 0 = stand, 1 = right, 2 = left, 3 = bush
	{
		try 
		{
			BufferedImage spriteSheet = ImageIO.read(getClass().getResourceAsStream("/sprites/flagsprites.gif"));
			flagSprites[0] =spriteSheet.getSubimage(0, 0, 120, 120);
			flagSprites[1] =spriteSheet.getSubimage(0, 120, 120, 120);
			
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void draw(Graphics2D graphics)
	{
		this.mapX = map.getX();
		this.mapY = map.getY();
		graphics.drawImage(flagSprites[flagged], (int) (this.agentX + this.mapX - this.agentWidth / 2), (int) (this.agentY + this.mapY - this.agentHeight / 2), null);
	}
	
}
