package Agents;

public class GravWall extends Agent {

	private double gravity;
	private double gravter;
	public GravWall(double x, double y, double gravity, double gravter)
	{
		this.agentX = x;
		this.agentY = y;
		this.agentWidth = 100;
		this.agentHeight = 900;
		this.gravity = gravity;
		this.gravter = gravter;
	}
	
	public double getGravter()
	{
		return gravter;
	}
	
	public double getGravity()
	{
		return gravity;
	}
	
}
