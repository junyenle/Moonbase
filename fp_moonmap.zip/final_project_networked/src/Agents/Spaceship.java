package Agents;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import Maps.Map;

public class Spaceship extends Agent{
	
	private ArrayList<BufferedImage> animationFrames = new ArrayList<BufferedImage>();
	private int animationInterval = 5;
	private int animationCount = 0;
	private int numFrames = 5;
	private Boolean moving = false;
	private Map map;
	
	public void setMoving (Boolean bool)
	{
		moving = bool;
	}
	
	public Spaceship(double x, double y, Map map)
	{
		this.agentX = x;
		this.agentY = y;
		this.agentWidth = 200;
		this.agentHeight = 600;
		this.map = map;
		
		try
		{
			BufferedImage spriteSheet = ImageIO.read(getClass().getResourceAsStream("/sprites/spaceship.png"));
			for(int i = 0; i < numFrames; i++)
			{
				animationFrames.add(spriteSheet.getSubimage(0, i * 1000, 1000, 1000));
			}
		} catch(Exception e)
		{
			// do nothing
		}
	}
	
	public void draw(Graphics2D graphics)
	{

		this.mapX = map.getX();
		this.mapY = map.getY();
		try
		{
			graphics.drawImage(animationFrames.get(animationCount / animationInterval), (int)(this.agentX + this.mapX - this.agentWidth / 2), (int) (this.agentY + this.mapY - this.agentHeight / 2), null);
		} catch (IndexOutOfBoundsException ioobe)
		{
			animationCount = 0;
		}
		//graphics.drawImage(animationFrames.get(animationCount / animationInterval),  1000,  500, null);
		if(moving)
		{
			animationCount += 1;
		}
	}

}
