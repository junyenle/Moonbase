package Agents;

public class DeathBar extends Agent{

	public DeathBar(double y)
	{
		this.agentX = 10000;
		this.agentY = y;
		this.agentHeight = 100;
		this.agentWidth = 20000;
	}
	
}
