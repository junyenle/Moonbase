package States;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

import Agents.Checkpoint;
import Agents.SoloPlayer;
import Driver.GameWindow;
import Maps.Map;


public class OnePGame extends GameState
{
	private SoloPlayer player;
	private BufferedImage background;
	private Map map;
	protected StateManager manager;
	
	private Checkpoint testPoint;
	
	// music
	private Boolean musicPlaying = false;
	private String musicFile = "/music/fungal.wav";
	private Clip clip = null;
	
	public OnePGame(StateManager manager)
	{
		this.manager = manager;
		setup(); // level setup
	}
	
	public void playMusic()
	{
		try{
		    AudioInputStream ais = AudioSystem.getAudioInputStream(getClass().getResource(this.musicFile));
		    clip = AudioSystem.getClip();
		    clip.open(ais);
		    ((FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN)).setValue((float) -5.0);
		    clip.loop(Clip.LOOP_CONTINUOUSLY);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void setup()
	{
		map = new Map("/tiles/leveltiles_space.gif", "/maps/onemap.txt");
		this.player = new SoloPlayer(map);
		this.testPoint = new Checkpoint(1700,1260, 0, map);
		player.setPosition(1100, 500);
		try {
			this.background = ImageIO.read(getClass().getResourceAsStream("/backgrounds/mountains.gif"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void update()
	{
		if(!musicPlaying)
		{
			playMusic();
			musicPlaying = true;
		}
		player.update(); // update player data
		if(player.isCollidingWith(testPoint))
		{
			if(testPoint.getFlag() == 0)
			{
				player.setPosition(2160, 660);
			}
			testPoint.setFlag(1);
		}
		map.setPosition(GameWindow.WIDTH / 2 - player.getAgentX(), GameWindow.HEIGHT / 2 - player.getAgentY()); // set the camera position
	}
	
	public void draw(Graphics2D graphics)
	{
		graphics.drawImage(this.background, 0, 0, null);
		this.map.draw(graphics); // then the map tiles
		this.player.draw(graphics); // then the player
		this.testPoint.draw(graphics);
	}
	
	public void keyPressed(int keyCode)
	{
		if(keyCode == KeyEvent.VK_ESCAPE)
		{
			clip.stop();
			musicPlaying = false;
			manager.setCurrentState(0);
			manager.playMenuMusic();
		}
		if(keyCode == KeyEvent.VK_LEFT)
		{
			player.setState(0);
			player.setAgentDX(0);
			player.setDirection(2); // left
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			player.setState(0);
			player.setAgentDX(0);
			player.setDirection(1); // right
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			player.setState(0);
			player.setJumping(true); // + DY
		}
	}
	
	public void keyReleased(int keyCode)
	{
		
		if(keyCode == KeyEvent.VK_LEFT)
		{
			player.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			player.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			player.setJumping(false); // no more + DY
			player.setJumped(true); // can't jump again
		}
		if(keyCode == KeyEvent.VK_DOWN)
		{
			player.nextState();
		}
	}
	
	
	
	
}
