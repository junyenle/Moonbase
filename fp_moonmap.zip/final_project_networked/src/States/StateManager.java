package States;

import java.awt.Graphics2D;
import java.net.Socket;
import java.util.Vector;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

public class StateManager 
{	
	// #DEFINE
	public static final int MENU = 0;
	public static final int ONEPGAME = 1;
	public static final int TWOPGAME = 2;
	public static final int GAMEPICKTWO = 3;
	public static final int GAMEPICKONE = 4;
	public static final int LOGIN = 5;
	public static final int REGISTER = 6;
	public static final int GAMEOVER = 7;
	
	// debug
	//public String host = "192.168.0.20";
	public String host = "localhost";	
	
	// graphics
	private Graphics2D graphics;
	
	// music
	private Clip menuMusic = null;
	private String menuMusicFile = "/music/fungal.wav";
	
	private Vector<GameState> states = new Vector<GameState>(); // vector of game states
	private int currentStateIndex = MENU; // index of the current state in the states vector
	
	public void setupMusic()
	{
		try{
			
		    AudioInputStream ais = AudioSystem.getAudioInputStream(getClass().getResource(this.menuMusicFile));
		    this.menuMusic = AudioSystem.getClip();
		    this.menuMusic.open(ais);
		    ((FloatControl) menuMusic.getControl(FloatControl.Type.MASTER_GAIN)).setValue((float) -5.0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public Graphics2D getGraphics()
	{
		return this.graphics;
	}
	
	public void playMenuMusic()
	{
		menuMusic.setMicrosecondPosition(0);
		menuMusic.loop(Clip.LOOP_CONTINUOUSLY);
	}
	
	public void stopMenuMusic()
	{
		menuMusic.stop();
	}
	
	public StateManager(Graphics2D graphics)
	{
		this.graphics = graphics;
		states.add(new MenuState(this));
		states.add(new OnePGame(this));
		states.add(null); // placeholder for 2p game
		states.add(new TwoPlayerPickState(this));
		states.add(new OnePlayerPickState(this));
		states.add(new LoginState(this));
		states.add(new RegisterState(this));
		states.add(new GameOver(this));
		setupMusic();
		playMenuMusic();	
		
	}
	
	// set a new state to be the current state
	public void setCurrentState(int state)
	{
		currentStateIndex = state;
		states.get(currentStateIndex).setup();
	}
	
	// update the current game state
	public void update()
	{
		states.get(currentStateIndex).update();
	}
	
	// sends graphics of current state to screen
	public void draw(Graphics2D graphics)
	{
		states.get(currentStateIndex).draw(graphics);
	}
	
	public void keyPressed(int keyCode)
	{
		states.get(currentStateIndex).keyPressed(keyCode);
	}
	
	public void keyReleased(int keyCode)
	{
		states.get(currentStateIndex).keyReleased(keyCode);
	}
	
	public void addTwoP(Socket s)
	{
		states.set(TWOPGAME, new TwoPGame(this, s));
	}
	
}
