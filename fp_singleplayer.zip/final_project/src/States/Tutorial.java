package States;

import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

import Agents.Hider;
import Driver.GameWindow;
import Maps.Map;


public class Tutorial extends GameState
{
	private Hider hider;
	private BufferedImage background;
	private Map map;
	protected StateManager manager;
	
	// music
	private Boolean musicPlaying = false;
	private String musicFile = "/music/fungal.wav";
	private Clip clip = null;
	
	public Tutorial(StateManager manager)
	{
		this.manager = manager;
		setup(); // level setup
	}
	
	public void playMusic()
	{
		try{
		    AudioInputStream ais = AudioSystem.getAudioInputStream(getClass().getResource(this.musicFile));
		    clip = AudioSystem.getClip();
		    clip.open(ais);
		    ((FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN)).setValue((float) -15.0);
		    clip.loop(Clip.LOOP_CONTINUOUSLY);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void setup()
	{
		map = new Map("/tiles/tutorialtiles.gif", "/maps/tutorialmap.txt");
		this.hider = new Hider(map);
		hider.setPosition(900, 500);
		try {
			this.background = ImageIO.read(getClass().getResourceAsStream("/backgrounds/mountains.gif"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void update()
	{
		if(!musicPlaying)
		{
			playMusic();
			musicPlaying = true;
		}
		hider.update(); // update player data
		map.setPosition(GameWindow.WIDTH / 2 - hider.getAgentX(), GameWindow.HEIGHT / 2 - hider.getAgentY()); // set the camera position
	}
	
	public void draw(Graphics2D graphics)
	{
		graphics.drawImage(this.background, 0, 0, null);
		this.map.draw(graphics); // then the map tiles
		this.hider.draw(graphics); // then the player
	}
	
	public void keyPressed(int keyCode)
	{
		if(keyCode == KeyEvent.VK_ESCAPE)
		{
			hider.setState(0);
			System.exit(0);
		}
		if(keyCode == KeyEvent.VK_LEFT)
		{
			hider.setState(0);
			hider.setAgentDX(0);
			hider.setDirection(2); // left
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			hider.setState(0);
			hider.setAgentDX(0);
			hider.setDirection(1); // right
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			hider.setState(0);
			hider.setJumping(true); // + DY
		}
	}
	
	public void keyReleased(int keyCode)
	{
		
		if(keyCode == KeyEvent.VK_LEFT)
		{
			hider.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			hider.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			hider.setJumping(false); // no more + DY
			hider.setJumped(true); // can't jump again
		}
		if(keyCode == KeyEvent.VK_DOWN)
		{
			hider.nextState();
		}
	}
	
	
	
	
}
