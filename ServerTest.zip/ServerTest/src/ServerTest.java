import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerTest {

	
	public static void main(String[] args)
	{
		System.out.println("Setting up server");
		try {
			ServerSocket ss = new ServerSocket(6789); // setup server
			
			System.out.println("Server listening");
			Socket s = ss.accept(); // accept connection
			
			System.out.println("Received connection.");
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
