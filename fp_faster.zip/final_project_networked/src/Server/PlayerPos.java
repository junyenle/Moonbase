package Server;

import java.io.Serializable;

public class PlayerPos implements Serializable
{
	public PlayerPos(short x, short y, short state, short dx, short dy)
	{
		this.x = x;
		this.y = y;
		this.state = state;
		this.dx = dx;
		this.dy = dy;
	}
	
	
	private short x;
	private short y;
	private short dx;
	private short dy;
	private short state;
	private int thread = -1;
	
	public short getX() {
		return x;
	}
	public short getY() {
		return y;
	}
	public short getDx() {
		return dx;
	}
	public short getDy() {
		return dy;
	}
	public short getState() {
		return state;
	}
	public int getThread() {
		return thread;
	}
	public void setX(short x) {
		this.x = x;
	}
	public void setY(short y) {
		this.y = y;
	}
	public void setDx(short dx) {
		this.dx = dx;
	}
	public void setDy(short dy) {
		this.dy = dy;
	}
	public void setState(short state) {
		this.state = state;
	}
	public void setThread(int thread) {
		this.thread = thread;
	}


}
