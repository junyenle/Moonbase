package States;

import java.awt.Graphics2D;
import java.net.Socket;
import java.util.Vector;

public class StateManager 
{	
	// #DEFINE
	public static final int MENU = 0;
	public static final int ONEPGAME = 1;
	public static final int TWOPGAME = 2;
	public static final int GAMEPICKTWO = 3;
	public static final int GAMEPICKONE = 4;
	public static final int LOGIN = 5;
	public static final int REGISTER = 6;
		
	private Vector<GameState> states = new Vector<GameState>(); // vector of game states
	private int currentStateIndex = MENU; // index of the current state in the states vector
	
	public StateManager()
	{
		states.add(new MenuState(this));
		states.add(new OnePGame(this));
		states.add(null); // placeholder for 2p game
		states.add(new TwoPlayerPickState(this));
		states.add(new OnePlayerPickState(this));
		states.add(new LoginState(this));
		states.add(new RegisterState(this));
	}
	
	// set a new state to be the current state
	public void setCurrentState(int state)
	{
		currentStateIndex = state;
		states.get(currentStateIndex).setup();
	}
	
	// update the current game state
	public void update()
	{
		states.get(currentStateIndex).update();
	}
	
	// sends graphics of current state to screen
	public void draw(Graphics2D graphics)
	{
		states.get(currentStateIndex).draw(graphics);
	}
	
	public void keyPressed(int keyCode)
	{
		states.get(currentStateIndex).keyPressed(keyCode);
	}
	
	public void keyReleased(int keyCode)
	{
		states.get(currentStateIndex).keyReleased(keyCode);
	}
	
	public void addTwoP(Socket s)
	{
		states.set(TWOPGAME, new TwoPGame(this, s));
	}
	
}
