package Server;

import java.io.Serializable;

public class PlayerPos implements Serializable
{
	public PlayerPos(double x, double y, int state, double dx, double dy)
	{
		this.x = x;
		this.y = y;
		this.state = state;
		this.dx = dx;
		this.dy = dy;
	}
	
	public double getX() {
		return x;
	}
	public double getY() {
		return y;
	}
	public int getState() {
		return state;
	}
	public int getThread()
	{
		return thread;
	}
	public void setThread(int t)
	{
		this.thread = t;
	}
	public double getDX()
	{
		return dx;
	}
	public double getDY()
	{
		return dy;
	}
	
	private double x;
	private double y;
	private int state;
	private double dx;
	private double dy;
	private int thread = -1;
}
