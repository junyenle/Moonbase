package StateManager;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

import Agents.Agent;
import Agents.Player;
import Driver.GamePanel;
import Graphics.Background;
import Maps.Map;


public class Tutorial extends GameState
{
	private Player player;
	private Background bg;
	private Map map;
	protected StateManager manager;
	
	public Tutorial(StateManager manager)
	{
		this.manager = manager;
		setup(); // level setup
	}
	
	public void setup()
	{
		this.bg = new Background("/backgrounds/tutorialbg.gif", 1);
		map = new Map("/tiles/tutorialtiles.gif", "/maps/tutorialmap.txt");
		this.player = new Player(map);
		player.setPosition(1000, 200);
	}
	
	public void update()
	{
		player.update();
		//map.setPosition(GamePanel.WIDTH / 2 - player.getAgentX(), GamePanel.HEIGHT / 2 - player.getAgentY());
	}
	
	public void draw(Graphics2D graphics)
	{
		this.bg.draw(graphics);
		this.map.draw(graphics);
		this.player.draw(graphics);
		
	}
	
	public void keyPressed(int keyCode)
	{
		if(keyCode == KeyEvent.VK_ESCAPE)
		{
			System.exit(0);
		}
		if(keyCode == KeyEvent.VK_LEFT)
		{
			player.setAgentDX(0);
			player.setDirection(2);
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			player.setAgentDX(0);
			player.setDirection(1);
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			player.setJumping(true);
		}
	}
	
	public void keyReleased(int keyCode)
	{
		
		if(keyCode == KeyEvent.VK_LEFT)
		{
			player.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_RIGHT)
		{
			player.setDirection(0);
		}
		if(keyCode == KeyEvent.VK_UP)
		{
			player.setJumping(false);
		}
	}
	
	
	
	
}
